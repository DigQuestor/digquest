import { S3Client, CreateBucketCommand, PutBucketCorsCommand } from '@aws-sdk/client-s3';

const s3Client = new S3Client({
  region: process.env.AWS_REGION!,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
  },
});

const BUCKET_NAME = process.env.AWS_S3_BUCKET_NAME!;

async function createS3Bucket() {
  try {
    console.log(`Creating S3 bucket: ${BUCKET_NAME}`);
    
    // Create the bucket
    await s3Client.send(new CreateBucketCommand({
      Bucket: BUCKET_NAME,
    }));
    
    console.log(`Bucket ${BUCKET_NAME} created successfully`);
    
    // Set CORS configuration to allow web access
    const corsParams = {
      Bucket: BUCKET_NAME,
      CORSConfiguration: {
        CORSRules: [
          {
            AllowedHeaders: ['*'],
            AllowedMethods: ['GET', 'POST', 'PUT', 'DELETE'],
            AllowedOrigins: ['*'],
            ExposeHeaders: ['ETag'],
          },
        ],
      },
    };
    
    await s3Client.send(new PutBucketCorsCommand(corsParams));
    console.log('CORS configuration set successfully');
    
  } catch (error: any) {
    if (error.name === 'BucketAlreadyOwnedByYou') {
      console.log(`Bucket ${BUCKET_NAME} already exists and is owned by you`);
    } else if (error.name === 'BucketAlreadyExists') {
      console.log(`Bucket ${BUCKET_NAME} already exists`);
    } else {
      console.error('Error creating bucket:', error);
      throw error;
    }
  }
}

// Run the setup
createS3Bucket()
  .then(() => {
    console.log('S3 setup completed successfully');
    process.exit(0);
  })
  .catch((error) => {
    console.error('S3 setup failed:', error);
    process.exit(1);
  });