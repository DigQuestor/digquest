import { S3Client, PutBucketPolicyCommand } from '@aws-sdk/client-s3';

const AWS_REGION = 'us-east-1';
const AWS_ACCESS_KEY_ID = 'AKIAZDLN3HTIH4JFRNE2';
const AWS_SECRET_ACCESS_KEY = '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';
const BUCKET_NAME = 'digquest-images';

const s3Client = new S3Client({
  region: AWS_REGION,
  credentials: {
    accessKeyId: AWS_ACCESS_KEY_ID,
    secretAccessKey: AWS_SECRET_ACCESS_KEY,
  },
});

async function setBucketPolicy() {
  try {
    console.log(`Setting public read policy for bucket: ${BUCKET_NAME}`);
    
    const bucketPolicy = {
      Version: "2012-10-17",
      Statement: [
        {
          Sid: "PublicReadGetObject",
          Effect: "Allow",
          Principal: "*",
          Action: "s3:GetObject",
          Resource: `arn:aws:s3:::${BUCKET_NAME}/*`
        }
      ]
    };

    const command = new PutBucketPolicyCommand({
      Bucket: BUCKET_NAME,
      Policy: JSON.stringify(bucketPolicy)
    });

    await s3Client.send(command);
    console.log('Bucket policy set successfully - all objects are now publicly readable');
    
  } catch (error) {
    console.error('Error setting bucket policy:', error);
    throw error;
  }
}

setBucketPolicy()
  .then(() => {
    console.log('Bucket policy setup completed successfully');
    process.exit(0);
  })
  .catch((error) => {
    console.error('Bucket policy setup failed:', error);
    process.exit(1);
  });