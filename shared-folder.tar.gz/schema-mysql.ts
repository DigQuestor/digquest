import { mysqlTable, text, int, boolean, timestamp, varchar } from "drizzle-orm/mysql-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = mysqlTable("users", {
  id: int("id").primaryKey().autoincrement(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  isEmailVerified: boolean("is_email_verified").default(false),
  emailVerificationToken: text("email_verification_token"),
  emailVerificationExpires: timestamp("email_verification_expires"),
  avatarUrl: text("avatar_url"),
  bio: text("bio"),
  created_at: timestamp("created_at").defaultNow(),
});

// Forum categories
export const categories = mysqlTable("categories", {
  id: int("id").primaryKey().autoincrement(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  icon: text("icon"),
  count: int("count").default(0),
});

// Forum posts
export const posts = mysqlTable("posts", {
  id: int("id").primaryKey().autoincrement(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  userId: int("user_id").notNull(),
  categoryId: int("category_id").notNull(),
  imageUrl: text("image_url"), // Optional image attachment
  views: int("views").default(0),
  comments: int("comments").default(0),
  created_at: timestamp("created_at").defaultNow(),
});

// Forum comments
export const comments = mysqlTable("comments", {
  id: int("id").primaryKey().autoincrement(),
  content: text("content").notNull(),
  userId: int("user_id").notNull(),
  postId: int("post_id").notNull(),
  created_at: timestamp("created_at").defaultNow(),
});

// Treasures (Finds)
export const finds = mysqlTable("finds", {
  id: int("id").primaryKey().autoincrement(),
  title: text("title").notNull(),
  description: text("description"),
  imageUrl: text("image_url").notNull(),
  userId: int("user_id").notNull(),
  location: text("location"),
  period: text("period"),  // e.g. "Roman", "Medieval", "Victorian"
  commentCount: int("comment_count").default(0),
  created_at: timestamp("created_at").defaultNow(),
});

// Detecting locations (Map pins)
export const locations = mysqlTable("locations", {
  id: int("id").primaryKey().autoincrement(),
  name: text("name").notNull(),
  description: text("description"),
  latitude: text("latitude").notNull(),
  longitude: text("longitude").notNull(),
  userId: int("user_id").notNull(),
  type: text("type"), // e.g. "Roman Site", "Beach", "Field"
  hasPermission: boolean("has_permission").default(false),
  isGroupDig: boolean("is_group_dig").default(false),
  created_at: timestamp("created_at").defaultNow(),
});

// Events
export const events = mysqlTable("events", {
  id: int("id").primaryKey().autoincrement(),
  title: text("title").notNull(),
  description: text("description"),
  location: text("location").notNull(),
  dateTime: timestamp("date_time").notNull(),
  organizerId: int("organizer_id").notNull(),
  maxParticipants: int("max_participants"),
  currentParticipants: int("current_participants").default(0),
  isPublic: boolean("is_public").default(true),
  created_at: timestamp("created_at").defaultNow(),
});

// Wellbeing stories
export const stories = mysqlTable("stories", {
  id: int("id").primaryKey().autoincrement(),
  content: text("content").notNull(),
  userId: int("user_id").notNull(),
  yearsDetecting: int("years_detecting"),
  created_at: timestamp("created_at").defaultNow(),
});

// Find comments (comments on treasure finds)
export const findComments = mysqlTable("find_comments", {
  id: int("id").primaryKey().autoincrement(),
  content: text("content").notNull(),
  userId: int("user_id").notNull(),
  findId: int("find_id").notNull(),
  created_at: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  avatarUrl: true,
  bio: true,
});

export const insertCategorySchema = createInsertSchema(categories).pick({
  name: true,
  slug: true,
  description: true,
  icon: true,
});

export const insertPostSchema = createInsertSchema(posts).pick({
  title: true,
  content: true,
  userId: true,
  categoryId: true,
  imageUrl: true,
});

export const insertCommentSchema = createInsertSchema(comments).pick({
  content: true,
  userId: true,
  postId: true,
});

export const insertFindSchema = createInsertSchema(finds).pick({
  title: true,
  description: true,
  imageUrl: true,
  userId: true,
  location: true,
  period: true,
});

export const insertLocationSchema = createInsertSchema(locations).pick({
  name: true,
  description: true,
  latitude: true,
  longitude: true,
  userId: true,
  type: true,
  hasPermission: true,
  isGroupDig: true,
});

export const insertEventSchema = createInsertSchema(events).pick({
  title: true,
  description: true,
  location: true,
  dateTime: true,
  organizerId: true,
  maxParticipants: true,
  isPublic: true,
});

export const insertStorySchema = createInsertSchema(stories).pick({
  content: true,
  userId: true,
  yearsDetecting: true,
});

export const insertFindCommentSchema = createInsertSchema(findComments).pick({
  content: true,
  userId: true,
  findId: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof posts.$inferSelect;

export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;

export type InsertFind = z.infer<typeof insertFindSchema>;
export type Find = typeof finds.$inferSelect;

export type InsertLocation = z.infer<typeof insertLocationSchema>;
export type Location = typeof locations.$inferSelect;

export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof events.$inferSelect;

export type InsertStory = z.infer<typeof insertStorySchema>;
export type Story = typeof stories.$inferSelect;

export type InsertFindComment = z.infer<typeof insertFindCommentSchema>;
export type FindComment = typeof findComments.$inferSelect;