import { useState } from "react";
import { Helmet } from "react-helmet";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Handshake, 
  TrendingUp, 
  Users, 
  Target, 
  DollarSign, 
  Star,
  CheckCircle,
  MapPin,
  Trophy,
  Heart,
  Download,
  Mail
} from "lucide-react";

const PartnershipProposal = () => {
  const [selectedTier, setSelectedTier] = useState("silver");

  const partnershipTiers = {
    bronze: {
      name: "Bronze Partner",
      price: "£200-500/year",
      color: "bg-amber-600",
      features: [
        "Basic business listing in directory",
        "Affiliate commission: 5% on referrals",
        "Community forum presence",
        "Monthly newsletter mention"
      ]
    },
    silver: {
      name: "Silver Partner", 
      price: "£500-1000/year",
      color: "bg-gray-400",
      features: [
        "Everything in Bronze",
        "Featured product showcases",
        "Priority placement in recommendations",
        "Affiliate commission: 6% on referrals",
        "Quarterly webinar opportunities",
        "Custom promotional content"
      ]
    },
    gold: {
      name: "Gold Partner",
      price: "£1000+/year", 
      color: "bg-metallic-gold",
      features: [
        "Everything in Silver",
        "Exclusive equipment category sponsorship",
        "AR Routes integration opportunities",
        "Affiliate commission: 8% on referrals",
        "Co-branded content creation",
        "Direct API integration options",
        "Dedicated account manager"
      ]
    }
  };

  const metrics = [
    { label: "Active Community Members", value: "2,500+", icon: <Users className="h-6 w-6" /> },
    { label: "Monthly Page Views", value: "45,000+", icon: <TrendingUp className="h-6 w-6" /> },
    { label: "Finds Shared Monthly", value: "350+", icon: <Trophy className="h-6 w-6" /> },
    { label: "UK Locations Covered", value: "1,200+", icon: <MapPin className="h-6 w-6" /> }
  ];

  return (
    <>
      <Helmet>
        <title>Partnership Opportunities | DigQuest</title>
        <meta name="description" content="Partner with DigQuest to reach thousands of passionate metal detecting enthusiasts across the UK." />
        <link rel="canonical" href="https://digquest.org/partnership" />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-br from-sand-beige to-earth-brown/20">
        <div className="container mx-auto px-4 py-12">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex justify-center mb-6">
              <Handshake className="h-16 w-16 text-metallic-gold" />
            </div>
            <h1 className="text-4xl font-bold text-earth-brown mb-4">
              Partnership Opportunities
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Join DigQuest in building the UK's premier metal detecting community. 
              Connect with passionate detectorists and grow your business through authentic partnerships.
            </p>
          </div>

          {/* Platform Metrics */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-center text-2xl text-earth-brown">
                Why Partner With DigQuest?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {metrics.map((metric, index) => (
                  <div key={index} className="text-center">
                    <div className="flex justify-center mb-3 text-forest-green">
                      {metric.icon}
                    </div>
                    <div className="text-2xl font-bold text-earth-brown">{metric.value}</div>
                    <div className="text-sm text-gray-600">{metric.label}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Partnership Types */}
          <Tabs defaultValue="equipment" className="mb-12">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="equipment">Equipment Retailers</TabsTrigger>
              <TabsTrigger value="clubs">Detecting Clubs</TabsTrigger>
              <TabsTrigger value="societies">Historical Societies</TabsTrigger>
            </TabsList>

            <TabsContent value="equipment" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-6 w-6 text-earth-brown" />
                    Equipment Retailer Partnership
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-3">What We Offer</h3>
                      <ul className="space-y-2">
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Authentic product reviews from real users
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Equipment recommendations in find posts
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Featured placement in equipment guides
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Integration with AR route recommendations
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-3">Revenue Model</h3>
                      <ul className="space-y-2">
                        <li className="flex items-center gap-2">
                          <DollarSign className="h-4 w-4 text-green-500" />
                          5-8% commission on referred sales
                        </li>
                        <li className="flex items-center gap-2">
                          <DollarSign className="h-4 w-4 text-green-500" />
                          Performance bonuses for high converters
                        </li>
                        <li className="flex items-center gap-2">
                          <DollarSign className="h-4 w-4 text-green-500" />
                          Volume discounts for long-term partners
                        </li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="clubs" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-6 w-6 text-forest-green" />
                    Metal Detecting Club Partnership
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-3">Club Benefits</h3>
                      <ul className="space-y-2">
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Dedicated club pages and member directory
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Event promotion and RSVP management
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Group dig coordination tools
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          New member recruitment assistance
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-3">Investment</h3>
                      <ul className="space-y-2">
                        <li>Annual partnership: £300-800</li>
                        <li>Event promotion: £50 per event</li>
                        <li>Custom features: Quote on request</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="societies" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Heart className="h-6 w-6 text-red-500" />
                    Historical Society Partnership
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-semibold mb-3">Collaboration Opportunities</h3>
                      <ul className="space-y-2">
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Historical period verification for finds
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Educational content creation
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Research data collection
                        </li>
                        <li className="flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Citizen archaeology initiatives
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-3">Partnership Investment</h3>
                      <ul className="space-y-2">
                        <li>Annual partnership: £500-1200</li>
                        <li>Content licensing: £100-300</li>
                        <li>Research projects: Custom quotes</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Partnership Tiers */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-center text-2xl text-earth-brown">
                Partnership Tiers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                {Object.entries(partnershipTiers).map(([key, tier]) => (
                  <Card 
                    key={key}
                    className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
                      selectedTier === key ? 'ring-2 ring-forest-green' : ''
                    }`}
                    onClick={() => setSelectedTier(key)}
                  >
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{tier.name}</CardTitle>
                        <Badge className={`${tier.color} text-white`}>
                          {tier.price}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {tier.features.map((feature, index) => (
                          <li key={index} className="flex items-start gap-2 text-sm">
                            <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Call to Action */}
          <Card className="bg-gradient-to-r from-forest-green to-earth-brown text-white">
            <CardContent className="pt-8">
              <div className="text-center space-y-6">
                <h2 className="text-3xl font-bold">Ready to Partner With Us?</h2>
                <p className="text-lg opacity-90 max-w-2xl mx-auto">
                  Join successful businesses already partnering with DigQuest to reach 
                  passionate metal detecting enthusiasts across the UK.
                </p>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button className="bg-white text-forest-green hover:bg-sand-beige">
                    <Mail className="h-4 w-4 mr-2" />
                    Contact Us
                  </Button>
                  <Button variant="outline" className="border-white text-white hover:bg-white hover:text-forest-green">
                    <Download className="h-4 w-4 mr-2" />
                    Download Proposal
                  </Button>
                </div>
                
                <div className="flex items-center justify-center gap-4 text-sm opacity-75">
                  <span>✓ No setup fees</span>
                  <span>✓ Flexible terms</span>
                  <span>✓ Performance tracking</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="text-center mt-12">
            <h3 className="text-xl font-semibold text-earth-brown mb-4">
              Let's Discuss Your Partnership
            </h3>
            <div className="space-y-2 text-gray-600">
              <p>Email: partnerships@digquest.org</p>
              <p>Phone: +44 (0) 123 456 789</p>
              <p>We typically respond within 24 hours</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default PartnershipProposal;