import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, MapPin, Calendar, User, Eye, MessageCircle, Coins, Waves, Users, CheckCircle, Star } from 'lucide-react';
import { Location, Find } from '@shared/schema';
import { getAvatarUrl, formatTimeAgo } from '@/lib/utils';
import { userCache } from '@/hooks/use-auth-simple';

interface IndexedBrowserProps {
  locations: Location[];
  finds: Find[];
}

export function IndexedBrowser({ locations, finds }: IndexedBrowserProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('locations');
  const [selectedFilter, setSelectedFilter] = useState<string | null>(null);

  // Filter and search locations
  const filteredLocations = useMemo(() => {
    let filtered = locations;

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(location =>
        location.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        location.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        location.type?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply category filter
    if (selectedFilter && selectedFilter !== 'all') {
      filtered = filtered.filter(location => {
        switch (selectedFilter) {
          case 'Roman Sites':
            return location.type === 'Roman Sites';
          case 'Beaches':
            return location.type === 'Beaches';
          case 'Permission Granted':
            return location.hasPermission;
          case 'Group Digs':
            return location.isGroupDig;
          default:
            return true;
        }
      });
    }

    return filtered.sort((a, b) => a.name.localeCompare(b.name));
  }, [locations, searchTerm, selectedFilter]);

  // Filter and search finds
  const filteredFinds = useMemo(() => {
    let filtered = finds;

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(find =>
        find.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        find.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        find.location?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        find.period?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Apply category filter for finds
    if (selectedFilter && selectedFilter !== 'all') {
      filtered = filtered.filter(find => {
        switch (selectedFilter) {
          case 'Roman':
            return find.period?.toLowerCase().includes('roman') || find.description?.toLowerCase().includes('roman');
          case 'Medieval':
            return find.period?.toLowerCase().includes('medieval') || find.description?.toLowerCase().includes('medieval');
          case 'Victorian':
            return find.period?.toLowerCase().includes('victorian') || find.description?.toLowerCase().includes('victorian');
          case 'Coins':
            return find.title.toLowerCase().includes('coin') || find.description?.toLowerCase().includes('coin');
          case 'Jewelry':
            return find.title.toLowerCase().includes('ring') || find.title.toLowerCase().includes('jewelry') || 
                   find.description?.toLowerCase().includes('ring') || find.description?.toLowerCase().includes('jewelry');
          default:
            return true;
        }
      });
    }

    return filtered.sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime());
  }, [finds, searchTerm, selectedFilter]);

  const getLocationIcon = (type: string) => {
    switch (type) {
      case 'Roman Sites':
        return <Coins className="h-4 w-4" />;
      case 'Beaches':
        return <Waves className="h-4 w-4" />;
      default:
        return <MapPin className="h-4 w-4" />;
    }
  };

  const getLocationTypeColor = (type: string) => {
    switch (type) {
      case 'Roman Sites':
        return 'bg-amber-100 text-amber-800';
      case 'Beaches':
        return 'bg-blue-100 text-blue-800';
      case 'Medieval Sites':
        return 'bg-purple-100 text-purple-800';
      case 'Victorian Sites':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <Card className="bg-sand-beige border-earth-brown">
      <CardHeader>
        <CardTitle className="text-earth-brown">Browse Locations & Finds</CardTitle>
        
        {/* Search Bar */}
        <div className="flex gap-3">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-3 h-4 w-4 text-earth-brown" />
            <Input
              type="text"
              placeholder="Search locations and finds..."
              className="bg-white text-forest-green pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          {searchTerm && (
            <Button
              variant="outline"
              onClick={() => setSearchTerm('')}
              className="border-earth-brown text-earth-brown hover:bg-earth-brown hover:text-sand-beige"
            >
              Clear
            </Button>
          )}
        </div>
      </CardHeader>
      
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="locations" className="data-[state=active]:bg-earth-brown data-[state=active]:text-sand-beige">
              Locations ({filteredLocations.length})
            </TabsTrigger>
            <TabsTrigger value="finds" className="data-[state=active]:bg-earth-brown data-[state=active]:text-sand-beige">
              Finds ({filteredFinds.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="locations" className="space-y-4">
            {/* Location Filters */}
            <div className="flex flex-wrap gap-2 mb-4">
              <Button
                variant={selectedFilter === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedFilter(selectedFilter === 'all' ? null : 'all')}
                className={selectedFilter === 'all' ? 'bg-earth-brown text-sand-beige' : 'border-earth-brown text-earth-brown'}
              >
                All
              </Button>
              <Button
                variant={selectedFilter === 'Roman Sites' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedFilter(selectedFilter === 'Roman Sites' ? null : 'Roman Sites')}
                className={selectedFilter === 'Roman Sites' ? 'bg-earth-brown text-sand-beige' : 'border-earth-brown text-earth-brown'}
              >
                <Coins className="h-3 w-3 mr-1" /> Roman Sites
              </Button>
              <Button
                variant={selectedFilter === 'Beaches' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedFilter(selectedFilter === 'Beaches' ? null : 'Beaches')}
                className={selectedFilter === 'Beaches' ? 'bg-earth-brown text-sand-beige' : 'border-earth-brown text-earth-brown'}
              >
                <Waves className="h-3 w-3 mr-1" /> Beaches
              </Button>
              <Button
                variant={selectedFilter === 'Permission Granted' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedFilter(selectedFilter === 'Permission Granted' ? null : 'Permission Granted')}
                className={selectedFilter === 'Permission Granted' ? 'bg-earth-brown text-sand-beige' : 'border-earth-brown text-earth-brown'}
              >
                <CheckCircle className="h-3 w-3 mr-1" /> Permission
              </Button>
              <Button
                variant={selectedFilter === 'Group Digs' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedFilter(selectedFilter === 'Group Digs' ? null : 'Group Digs')}
                className={selectedFilter === 'Group Digs' ? 'bg-earth-brown text-sand-beige' : 'border-earth-brown text-earth-brown'}
              >
                <Users className="h-3 w-3 mr-1" /> Group Digs
              </Button>
            </div>

            {/* Locations Grid - Only show when a filter is selected */}
            {selectedFilter && (
              <div className="grid gap-3 max-h-96 overflow-y-auto">
                {filteredLocations.map((location) => {
                const user = userCache.getUserById(location.userId);
                return (
                  <div key={location.id} className="bg-white p-4 rounded-lg border border-earth-brown/20 hover:border-earth-brown transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex-grow">
                        <div className="flex items-center gap-2 mb-2">
                          {getLocationIcon(location.type || 'General')}
                          <h4 className="font-semibold text-forest-green">{location.name}</h4>
                          <Badge className={getLocationTypeColor(location.type || 'General')}>
                            {location.type || 'General'}
                          </Badge>
                        </div>
                        
                        {location.description && (
                          <p className="text-sm text-gray-600 mb-2 line-clamp-2">{location.description}</p>
                        )}
                        
                        <div className="flex items-center gap-4 text-xs text-gray-500">
                          {user && (
                            <div className="flex items-center gap-1">
                              <User className="h-3 w-3" />
                              {user.username}
                            </div>
                          )}
                          {location.hasPermission && (
                            <div className="flex items-center gap-1 text-green-600">
                              <CheckCircle className="h-3 w-3" />
                              Permission
                            </div>
                          )}
                          {location.isGroupDig && (
                            <div className="flex items-center gap-1 text-blue-600">
                              <Users className="h-3 w-3" />
                              Group Dig
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
                })}
                
                {filteredLocations.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <MapPin className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No locations found matching your search</p>
                  </div>
                )}
              </div>
            )}

            {/* Show message when no filter is selected */}
            {!selectedFilter && (
              <div className="text-center py-12 text-gray-500">
                <MapPin className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p className="text-lg font-medium mb-2">Choose a filter to browse locations</p>
                <p className="text-sm">Select one of the filter options above to see locations in that category</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="finds" className="space-y-4">
            {/* Find Filters */}
            <div className="flex flex-wrap gap-2 mb-4">
              <Button
                variant={selectedFilter === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedFilter(selectedFilter === 'all' ? null : 'all')}
                className={selectedFilter === 'all' ? 'bg-earth-brown text-sand-beige' : 'border-earth-brown text-earth-brown'}
              >
                All
              </Button>
              <Button
                variant={selectedFilter === 'Roman' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedFilter(selectedFilter === 'Roman' ? null : 'Roman')}
                className={selectedFilter === 'Roman' ? 'bg-earth-brown text-sand-beige' : 'border-earth-brown text-earth-brown'}
              >
                <Coins className="h-3 w-3 mr-1" /> Roman
              </Button>
              <Button
                variant={selectedFilter === 'Medieval' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedFilter(selectedFilter === 'Medieval' ? null : 'Medieval')}
                className={selectedFilter === 'Medieval' ? 'bg-earth-brown text-sand-beige' : 'border-earth-brown text-earth-brown'}
              >
                <Star className="h-3 w-3 mr-1" /> Medieval
              </Button>
              <Button
                variant={selectedFilter === 'Victorian' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedFilter(selectedFilter === 'Victorian' ? null : 'Victorian')}
                className={selectedFilter === 'Victorian' ? 'bg-earth-brown text-sand-beige' : 'border-earth-brown text-earth-brown'}
              >
                <Users className="h-3 w-3 mr-1" /> Victorian
              </Button>
              <Button
                variant={selectedFilter === 'Coins' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedFilter(selectedFilter === 'Coins' ? null : 'Coins')}
                className={selectedFilter === 'Coins' ? 'bg-earth-brown text-sand-beige' : 'border-earth-brown text-earth-brown'}
              >
                <Coins className="h-3 w-3 mr-1" /> Coins
              </Button>
              <Button
                variant={selectedFilter === 'Jewelry' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedFilter(selectedFilter === 'Jewelry' ? null : 'Jewelry')}
                className={selectedFilter === 'Jewelry' ? 'bg-earth-brown text-sand-beige' : 'border-earth-brown text-earth-brown'}
              >
                <Star className="h-3 w-3 mr-1" /> Jewelry
              </Button>
            </div>

            {/* Finds Grid - Only show when a filter is selected */}
            {selectedFilter && (
              <div className="grid gap-3 max-h-96 overflow-y-auto">
                {filteredFinds.map((find) => {
                const user = userCache.getUserById(find.userId);
                return (
                  <div key={find.id} className="bg-white p-4 rounded-lg border border-earth-brown/20 hover:border-earth-brown transition-colors">
                    <div className="flex gap-3">
                      {find.imageUrl && (
                        <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                          <img 
                            src={find.imageUrl} 
                            alt={find.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                      
                      <div className="flex-grow min-w-0">
                        <h4 className="font-semibold text-forest-green mb-1 truncate">{find.title}</h4>
                        
                        {find.description && (
                          <p className="text-sm text-gray-600 mb-2 line-clamp-2">{find.description}</p>
                        )}
                        
                        <div className="flex flex-wrap items-center gap-3 text-xs text-gray-500">
                          {user && (
                            <div className="flex items-center gap-1">
                              <Avatar className="h-4 w-4">
                                <AvatarImage src={getAvatarUrl(user)} />
                                <AvatarFallback className="text-[8px]">
                                  {user.username.slice(0, 2).toUpperCase()}
                                </AvatarFallback>
                              </Avatar>
                              {user.username}
                            </div>
                          )}
                          
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {formatTimeAgo(find.created_at)}
                          </div>
                          
                          {find.location && (
                            <div className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {find.location}
                            </div>
                          )}
                          
                          {find.period && (
                            <Badge variant="secondary" className="text-xs">
                              {find.period}
                            </Badge>
                          )}
                          
                          {find.commentCount > 0 && (
                            <div className="flex items-center gap-1">
                              <MessageCircle className="h-3 w-3" />
                              {find.commentCount}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
                })}
                
                {filteredFinds.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Star className="h-12 w-12 mx-auto mb-3 opacity-50" />
                    <p>No finds found matching your search</p>
                  </div>
                )}
              </div>
            )}

            {/* Show message when no filter is selected */}
            {!selectedFilter && (
              <div className="text-center py-12 text-gray-500">
                <Star className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p className="text-lg font-medium mb-2">Choose a filter to browse finds</p>
                <p className="text-sm">Select one of the filter options above to see finds in that category</p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}