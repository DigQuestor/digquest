import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Heart, Building2, Factory, X, ExternalLink, Mail, Phone } from "lucide-react";

const DonationBanner = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [dontShowAgain, setDontShowAgain] = useState(false);

  useEffect(() => {
    // Check if user has seen the donation banner before
    const hasSeenBanner = localStorage.getItem('digquest-donation-banner-seen');
    
    if (!hasSeenBanner) {
      // Show banner after a short delay to let the page load
      const timer = setTimeout(() => {
        setIsOpen(true);
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  }, []);

  const handleLearnMore = () => {
    setShowDetails(true);
  };

  const handleClose = () => {
    setIsOpen(false);
    setShowDetails(false);
    if (dontShowAgain) {
      localStorage.setItem('digquest-donation-banner-seen', 'true');
    }
  };

  const handleDismiss = () => {
    setIsOpen(false);
    setShowDetails(false);
    if (dontShowAgain) {
      localStorage.setItem('digquest-donation-banner-seen', 'true');
    }
  };

  const handleBack = () => {
    setShowDetails(false);
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={handleDismiss}>
      <DialogContent className={`bg-gradient-to-br from-amber-50 to-orange-100 border-amber-200 max-h-[90vh] overflow-y-auto ${showDetails ? 'max-w-[95vw] sm:max-w-2xl' : 'max-w-[90vw] sm:max-w-md'}`}>
        <button
          onClick={handleClose}
          className="absolute right-4 top-4 rounded-sm opacity-70 hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-amber-400 focus:ring-offset-2 z-10"
        >
          <X className="h-4 w-4" />
        </button>
        
        {!showDetails ? (
          // Initial banner view
          <>
            <DialogHeader className="text-center pb-2">
              <DialogTitle className="text-lg sm:text-xl font-bold text-amber-800 flex items-center justify-center gap-2">
                <Heart className="h-5 w-5 sm:h-6 sm:w-6 text-red-500" />
                Support Our Community
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-3 sm:space-y-4 text-center px-2">
              <p className="text-sm sm:text-base text-amber-700 font-medium">
                Help Build the Ultimate Metal Detecting Platform
              </p>
              
              <div className="space-y-2 sm:space-y-3 text-xs sm:text-sm text-amber-800">
                <div className="flex items-start gap-2 sm:gap-3 text-left">
                  <Building2 className="h-4 w-4 sm:h-5 sm:w-5 text-amber-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-xs sm:text-sm">Metal Detecting Associations</p>
                    <p className="text-xs">Support community growth and responsible detecting education</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-2 sm:gap-3 text-left">
                  <Factory className="h-4 w-4 sm:h-5 sm:w-5 text-amber-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="font-semibold text-xs sm:text-sm">Equipment Manufacturers</p>
                    <p className="text-xs">Reach engaged customers through advertising partnerships</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/60 rounded-lg p-2 sm:p-3 text-xs text-amber-800">
                <p className="font-medium mb-1">Your donation helps fund:</p>
                <p className="text-xs leading-relaxed">• Platform hosting & development<br/>• Community features<br/>• Educational resources</p>
              </div>
              
              <div className="flex items-center space-x-2 justify-center pt-1 pb-2">
                <Checkbox 
                  id="dont-show-again" 
                  checked={dontShowAgain}
                  onCheckedChange={setDontShowAgain}
                  className="border-amber-400 data-[state=checked]:bg-amber-600 h-3 w-3 sm:h-4 sm:w-4"
                />
                <label 
                  htmlFor="dont-show-again" 
                  className="text-xs text-amber-700 cursor-pointer leading-tight"
                >
                  Don't show me this message again
                </label>
              </div>

              <div className="flex flex-col sm:flex-row gap-2">
                <Button 
                  onClick={handleLearnMore}
                  className="flex-1 bg-amber-600 hover:bg-amber-700 text-white text-sm py-2"
                >
                  Learn More
                </Button>
                <Button 
                  onClick={handleDismiss}
                  variant="outline" 
                  className="flex-1 border-amber-300 text-amber-700 hover:bg-amber-100 text-sm py-2"
                >
                  Maybe Later
                </Button>
              </div>
              
              <p className="text-xs text-amber-600 pt-1 leading-relaxed">
                All donations welcome<br className="sm:hidden" /><span className="hidden sm:inline"> • </span>Advertising opportunities available
              </p>
            </div>
          </>
        ) : (
          // Detailed donation information view
          <>
            <DialogHeader className="text-center pb-3 sm:pb-4">
              <DialogTitle className="text-lg sm:text-xl font-bold text-amber-800 flex items-center justify-center gap-2">
                <Heart className="h-5 w-5 sm:h-6 sm:w-6 text-red-500" />
                <span className="text-center leading-tight">Partnership & Donation Opportunities</span>
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4 sm:space-y-6 text-amber-800 px-1">
              <div className="text-center">
                <p className="font-semibold text-base sm:text-lg mb-2">Help Build DigQuest Community</p>
                <p className="text-xs sm:text-sm leading-relaxed">Your support helps us create the ultimate platform for metal detecting enthusiasts worldwide</p>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div className="space-y-3 sm:space-y-4">
                  <div className="bg-white/60 rounded-lg p-3 sm:p-4">
                    <div className="flex items-center gap-2 mb-2 sm:mb-3">
                      <Building2 className="h-4 w-4 sm:h-5 sm:w-5 text-amber-600" />
                      <h3 className="font-semibold text-sm sm:text-base">For Associations</h3>
                    </div>
                    <ul className="text-xs space-y-0.5">
                      <li>• Support community growth</li>
                      <li>• Promote responsible detecting</li>
                      <li>• Educational resource funding</li>
                      <li>• Member engagement tools</li>
                    </ul>
                  </div>
                  
                  <div className="bg-white/60 rounded-lg p-3 sm:p-4">
                    <div className="flex items-center gap-2 mb-2 sm:mb-3">
                      <Factory className="h-4 w-4 sm:h-5 sm:w-5 text-amber-600" />
                      <h3 className="font-semibold text-sm sm:text-base">For Manufacturers</h3>
                    </div>
                    <ul className="text-xs space-y-0.5">
                      <li>• Banner advertising opportunities</li>
                      <li>• Product showcase features</li>
                      <li>• Engaged customer base</li>
                      <li>• Sponsored content options</li>
                    </ul>
                  </div>
                </div>
                
                <div className="space-y-3 sm:space-y-4">
                  <div className="bg-white/60 rounded-lg p-3 sm:p-4">
                    <h3 className="font-semibold mb-2 sm:mb-3 text-sm sm:text-base">How Donations Help</h3>
                    <ul className="text-xs space-y-0.5">
                      <li>• Platform hosting & infrastructure</li>
                      <li>• Feature development & maintenance</li>
                      <li>• Community support tools</li>
                      <li>• Educational content creation</li>
                      <li>• Security & data protection</li>
                    </ul>
                  </div>
                  
                  <div className="bg-white/60 rounded-lg p-3 sm:p-4">
                    <h3 className="font-semibold mb-2 sm:mb-3 text-sm sm:text-base">Get In Touch</h3>
                    <div className="text-xs space-y-2">
                      <div className="flex items-center gap-2 break-all">
                        <Mail className="h-3 w-3 flex-shrink-0" />
                        <span>danishnest@gmail.com</span>
                      </div>
                      <div className="flex items-center gap-2 break-all">
                        <ExternalLink className="h-3 w-3 flex-shrink-0" />
                        <span>Visit digquest.org/partnership</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-2 pt-3 sm:pt-4">
                <Button 
                  onClick={handleBack}
                  variant="outline" 
                  className="border-amber-300 text-amber-700 hover:bg-amber-100 text-sm py-2"
                >
                  Back
                </Button>
                <Button 
                  onClick={handleClose}
                  className="flex-1 bg-amber-600 hover:bg-amber-700 text-white text-sm py-2"
                >
                  Close
                </Button>
              </div>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default DonationBanner;