import { Link } from "wouter";
import { 
  Shovel,
  Facebook,
  Twitter,
  Instagram,
  Youtube
} from "lucide-react";

const Footer = () => {

  return (
    <footer className="bg-forest-green text-sand-beige py-10">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <Shovel className="h-6 w-6 text-metallic-gold mr-3" />
              <h2 className="font-display text-2xl font-bold text-sand-beige">DigQuest</h2>
            </div>
            <p className="mb-4">Connecting metal detecting enthusiasts for wellbeing, community, and discovery.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-sand-beige hover:text-metallic-gold transition duration-300">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-sand-beige hover:text-metallic-gold transition duration-300">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-sand-beige hover:text-metallic-gold transition duration-300">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-sand-beige hover:text-metallic-gold transition duration-300">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-display text-xl mb-4 text-sand-beige">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link 
                  href="/" 
                  className="text-sand-beige hover:text-metallic-gold transition duration-300"
                  onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                >
                  Home
                </Link>
              </li>
              <li>
                <Link 
                  href="/forum" 
                  className="text-sand-beige hover:text-metallic-gold transition duration-300"
                  onClick={() => {
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 100);
                  }}
                >
                  Forum
                </Link>
              </li>
              <li>
                <Link 
                  href="/finds" 
                  className="text-sand-beige hover:text-metallic-gold transition duration-300"
                  onClick={() => {
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 100);
                  }}
                >
                  Finds Gallery
                </Link>
              </li>
              <li>
                <Link 
                  href="/map" 
                  className="text-sand-beige hover:text-metallic-gold transition duration-300"
                  onClick={() => {
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 100);
                  }}
                >
                  Detecting Map
                </Link>
              </li>
              <li>
                <Link 
                  href="/wellbeing" 
                  className="text-sand-beige hover:text-metallic-gold transition duration-300"
                  onClick={() => {
                    setTimeout(() => {
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }, 100);
                  }}
                >
                  Wellbeing Resources
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-display text-xl mb-4 text-sand-beige">Resources</h3>
            <ul className="space-y-2">
              <li>
                <span className="text-sand-beige/70 cursor-default">Beginner's Guide <span className="text-xs text-metallic-gold">(Coming Soon)</span></span>
              </li>
              <li>
                <span className="text-sand-beige/70 cursor-default">Code of Conduct <span className="text-xs text-metallic-gold">(Coming Soon)</span></span>
              </li>
              <li>
                <span className="text-sand-beige/70 cursor-default">Equipment Reviews <span className="text-xs text-metallic-gold">(Coming Soon)</span></span>
              </li>
              <li>
                <span className="text-sand-beige/70 cursor-default">Find Authentication <span className="text-xs text-metallic-gold">(Coming Soon)</span></span>
              </li>
              <li>
                <span className="text-sand-beige/70 cursor-default">Legal Guidelines <span className="text-xs text-metallic-gold">(Coming Soon)</span></span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-600 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p>&copy; {new Date().getFullYear()} DigQuest - Metal Detecting for Wellbeing. All rights reserved.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <span className="text-sand-beige/70 cursor-default">Privacy Policy <span className="text-xs text-metallic-gold">(Coming Soon)</span></span>
            <span className="text-sand-beige/70 cursor-default">Terms of Service <span className="text-xs text-metallic-gold">(Coming Soon)</span></span>
            <span className="text-sand-beige/70 cursor-default">Contact Us <span className="text-xs text-metallic-gold">(Coming Soon)</span></span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
