interface Window {
  handleDeleteLocationClick: (locationId: number) => void;
}