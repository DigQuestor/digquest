import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ui/theme-provider";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Navigation from "@/components/Navigation";
import Home from "@/pages/Home";
import Forum from "@/pages/Forum";
import ForumPostDetail from "@/pages/ForumPostDetail";
import FindsGallery from "@/pages/FindsGallery";
import FindDetail from "@/pages/FindDetail";
import DetectingMap from "@/pages/DetectingMap";
import ARRoutes from "@/pages/ARRoutes";
import Wellbeing from "@/pages/Wellbeing";
import ProfileEdit from "@/pages/ProfileEdit";
import EventDetail from "@/pages/EventDetail";
import EmailVerification from "@/pages/EmailVerification";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <Navigation />
      <main className="flex-grow bg-sand-beige">
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/forum" component={Forum} />
          <Route path="/forum/:id" component={ForumPostDetail} />
          <Route path="/finds" component={FindsGallery} />
          <Route path="/finds/:id" component={FindDetail} />
          <Route path="/map" component={DetectingMap} />
          <Route path="/routes" component={ARRoutes} />
          <Route path="/wellbeing" component={Wellbeing} />
          <Route path="/events/:id" component={EventDetail} />
          <Route path="/profile/edit" component={ProfileEdit} />
          <Route path="/verify-email" component={EmailVerification} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="digquest-theme">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;